<?php
echo $content;