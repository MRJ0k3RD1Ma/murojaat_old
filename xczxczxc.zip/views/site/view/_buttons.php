
<div class="dropdown" style="display: inline-block">
    <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Топшириқ юбориш
    </button>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item" data-toggle="collapse" href="#success">Ташкилотларга топшириқ бериш</a>
        <a class="dropdown-item" data-toggle="collapse" href="#">Ҳодимларга топшириқ бериш</a>
    </div>
</div>
<a href="#answer" class="btn btn-success" data-toggle="collapse">Жавоб юбориш</a>