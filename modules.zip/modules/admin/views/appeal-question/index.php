<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\search\AppealQuestionSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Appeal Questions';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="appeal-question-index">

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-tools">
                        <?= Html::a('Қўшиш Appeal Question', ['create'], ['class' => 'btn btn-success']) ?>

                    </div>
                </div>
                <div class="card-body">

                    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>
                    <?php
                    $res = [];
                    foreach (\app\models\AppealQuestionGroup::find()->all() as $item){
                        $res[$item->id] = $item->code.'-'.$item->name;
                    }
                    ?>
                    <?= GridView::widget([
                        'dataProvider' => $dataProvider,
                        'filterModel' => $searchModel,
                        'columns' => [
                            ['class' => 'yii\grid\SerialColumn'],

//                                    'id',
//            'group_id',
                            [
                                'attribute' => 'group_id',
                                'value' => function ($d) {
                                    $gr = $d->group;
                                    return $gr->code . ' ' . $gr->name;
                                },
                                'filter' => $res,
                            ],
                            'code',
                            'name',

                            ['class' => 'yii\grid\ActionColumn'],
                        ],
                    ]); ?>

                </div>
            </div>
        </div>
    </div>


</div>
